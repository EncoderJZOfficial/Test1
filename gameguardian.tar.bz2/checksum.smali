.class public Lcom/android/support/Checksum;
.super Ljava/lang/Object;
.source "Checksum.java"


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 83
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static checker(Landroid/content/Context;Ljava/lang/String;)V
    .registers 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 23
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v11, v0

    :try_start_5
    invoke-virtual {v11}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v11

    move-object v12, v0

    invoke-virtual {v12}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x40

    invoke-virtual {v11, v12, v13}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v11

    iget-object v11, v11, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    move-object v3, v11

    .line 24
    const-string v11, "WDUwOQ=="

    invoke-static {v11}, Lcom/android/support/Checksum;->text(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    move-result-object v11

    new-instance v12, Ljava/io/ByteArrayInputStream;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    move-object v14, v3

    const/4 v15, 0x0

    aget-object v14, v14, v15

    invoke-virtual {v14}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v14

    invoke-direct {v13, v14}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-virtual {v11, v12}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    move-result-object v11

    check-cast v11, Ljava/security/cert/X509Certificate;

    move-object v4, v11

    .line 25
    const-string v11, "U0hBMQ=="

    invoke-static {v11}, Lcom/android/support/Checksum;->text(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v11

    move-object v12, v4

    invoke-virtual {v12}, Ljava/security/cert/X509Certificate;->getEncoded()[B

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v11

    move-object v5, v11

    .line 26
    new-instance v11, Ljava/lang/StringBuilder;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v5

    array-length v13, v13

    const/4 v14, 0x2

    mul-int/lit8 v13, v13, 0x2

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(I)V

    move-object v6, v11

    .line 27
    const/4 v11, 0x0

    move v7, v11

    :goto_62
    move v11, v7

    move-object v12, v5

    array-length v12, v12

    if-lt v11, v12, :cond_86

    .line 35
    move-object v11, v6

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 36
    move-object v11, v7

    move-object v12, v1

    invoke-static {v12}, Lcom/android/support/Checksum;->text(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_df

    .line 41
    :goto_79
    move-object v11, v7

    move-object v12, v1

    invoke-static {v12}, Lcom/android/support/Checksum;->text(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_113

    .line 82
    :goto_85
    return-void

    .line 28
    :cond_86
    move-object v11, v5

    move v12, v7

    aget-byte v11, v11, v12

    invoke-static {v11}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v11

    move-object v8, v11

    .line 29
    move-object v11, v8

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v11

    move v9, v11

    .line 30
    move v11, v9

    const/4 v12, 0x1

    if-ne v11, v12, :cond_b4

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "0"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v8

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    move-object v8, v11

    .line 31
    :cond_b4
    move v11, v9

    const/4 v12, 0x2

    if-le v11, v12, :cond_c3

    move-object v11, v8

    move v12, v9

    const/4 v13, 0x2

    add-int/lit8 v12, v12, -0x2

    move v13, v9

    invoke-virtual {v11, v12, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    move-object v8, v11

    .line 32
    :cond_c3
    move-object v11, v6

    move-object v12, v8

    invoke-virtual {v12}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    .line 33
    move v11, v7

    move-object v12, v5

    array-length v12, v12

    const/4 v13, 0x1

    add-int/lit8 v12, v12, -0x1

    if-ge v11, v12, :cond_dc

    move-object v11, v6

    const/16 v12, 0x3a

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v11

    .line 27
    :cond_dc
    add-int/lit8 v7, v7, 0x1

    goto :goto_62

    .line 39
    :cond_df
    const/4 v11, 0x0

    invoke-static {v11}, Ljava/lang/System;->exit(I)V
    :try_end_e3
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_e3} :catch_e4

    goto :goto_79

    .line 45
    :catch_e4
    move-exception v11

    move-object v3, v11

    .line 81
    move-object v11, v0

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "RXJyb3I6IA=="

    invoke-static {v13}, Lcom/android/support/Checksum;->text(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v3

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x1

    invoke-static {v11, v12, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v11

    invoke-virtual {v11}, Landroid/widget/Toast;->show()V

    .line 82
    const/4 v11, 0x0

    invoke-static {v11}, Ljava/lang/System;->exit(I)V

    goto/16 :goto_85

    .line 44
    :cond_113
    :try_start_113
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v11

    move v8, v11

    .line 45
    move v11, v8

    invoke-static {v11}, Landroid/os/Process;->killProcess(I)V
    :try_end_11c
    .catch Ljava/lang/Exception; {:try_start_113 .. :try_end_11c} :catch_e4

    goto/16 :goto_85
.end method

.method public static text(Ljava/lang/String;)Ljava/lang/String;
    .registers 12

    .prologue
    .line 14
    move-object v0, p0

    const-string v6, ""

    move-object v3, v6

    .line 17
    :try_start_4
    new-instance v6, Ljava/lang/String;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    const/4 v9, 0x0

    invoke-static {v8, v9}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v8

    const-string v9, "UTF-8"

    invoke-direct {v7, v8, v9}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_14} :catch_1a

    move-object v3, v6

    .line 18
    :goto_15
    move-object v6, v3

    move-object v2, v6

    .line 19
    move-object v6, v2

    move-object v0, v6

    return-object v0

    .line 17
    :catch_1a
    move-exception v6

    move-object v4, v6

    goto :goto_15
.end method
