
MODPATH=${0%/*}
BOOTSTAGE="post"

# Load functions
. $MODPATH/common/util_functions.sh

rm -rf "$MHPCPATH"

for ITEM in $CACHEFILES; do
	rm -f $CACHELOC/$ITEM
done
